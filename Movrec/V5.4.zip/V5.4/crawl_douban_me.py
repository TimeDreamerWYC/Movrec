# -*- coding: utf-8 -*-
"""
crawl_douban_me2.py - 高效版本
只显示页面完成提示，不显示单个电影详情
"""

import re
import time
import random
import argparse
import json
from urllib.parse import urljoin
import requests
from bs4 import BeautifulSoup
from tenacity import retry, wait_fixed, stop_after_attempt
import pandas as pd

MOBILE_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

def parse_cookie_str(cookie_str: str) -> dict:
    """把 'a=1; b=2; dbcl2="xxx"' 转成 dict"""
    jar = {}
    for part in cookie_str.split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            jar[k.strip()] = v.strip()
    return jar

class DoubanClient:
    def __init__(self, cookies: str | None = None, base: str = "https://www.douban.com"):
        self.base = base.rstrip("/") + "/"
        self.sess = requests.Session()
        self.sess.headers.update({
            "User-Agent": MOBILE_UA,
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Referer": "https://www.douban.com/",
            "Connection": "keep-alive",
        })
        if cookies:
            self.sess.cookies.update(parse_cookie_str(cookies))

    @retry(wait=wait_fixed(2), stop=stop_after_attempt(3), reraise=True)
    def get(self, url: str, params: dict | None = None) -> requests.Response:
        resp = self.sess.get(url, params=params, timeout=15)
        if resp.status_code in (403, 429):
            raise requests.HTTPError(f"HTTP {resp.status_code}")
        resp.raise_for_status()
        return resp

    def soup(self, path_or_url: str, params: dict | None = None) -> BeautifulSoup:
        url = path_or_url if path_or_url.startswith("http") else urljoin(self.base, path_or_url)
        r = self.get(url, params=params)
        return BeautifulSoup(r.text, "lxml")

def text_or_none(el):
    return el.get_text(strip=True) if el else None

# ---------------- 电影详情/评分/短评 ----------------

def parse_movie_reviews(client: DoubanClient, movie_url: str, max_reviews=5) -> list[str]:
    """获取电影短评，默认最多5条"""
    reviews_list = []
    try:
        m = re.search(r'/subject/(\d+)/', movie_url)
        if not m:
            return reviews_list
        movie_id = m.group(1)
        review_url = f"https://movie.douban.com/subject/{movie_id}/comments"

        # 只抓取第一页，获取前5条短评
        params = {'start': 0, 'limit': 20, 'status': 'P', 'sort': 'new_score'}
        try:
            review_soup = client.soup(review_url, params=params)
            for item in review_soup.find_all('div', class_='comment-item'):
                if len(reviews_list) >= max_reviews:
                    break
                short = item.find('span', class_='short')
                if not short:
                    continue
                text = short.get_text().strip()
                if len(text) > 5 and not text.startswith('未通过验证') and '账号异常' not in text:
                    reviews_list.append(text)
        except Exception:
            pass  # 短评失败静默处理
    except Exception:
        pass  # 短评失败静默处理
    return reviews_list

def parse_movie_details(client: DoubanClient, movie_url: str) -> dict:
    """获取电影详细信息"""
    try:
        soup = client.soup(movie_url)
        details = {}
        
        # 获取豆瓣ID
        m = re.search(r'/subject/(\d+)/', movie_url)
        details["douban_id"] = m.group(1) if m else ""
        
        # 电影名称
        title_el = soup.select_one('h1 span[property="v:itemreviewed"]')
        details["title"] = text_or_none(title_el)
        
        # 电影别名
        alias_el = soup.find('span', class_='pl', string=re.compile('又名'))
        if alias_el:
            alias = alias_el.next_sibling
            details["alias"] = alias.strip() if alias else ""
        else:
            details["alias"] = ""
        
        # 导演
        director_els = soup.select('a[rel="v:directedBy"]')
        directors = " / ".join([el.get_text(strip=True) for el in director_els]) if director_els else ""
        details["director"] = directors

        # 简介
        summary_el = soup.select_one('span[property="v:summary"]')
        summary = text_or_none(summary_el)
        if summary:
            summary = re.sub(r'\s+', ' ', summary).strip()
        details["summary"] = summary

        # 评分
        rating_el = soup.select_one('strong[property="v:average"]')
        details["rating"] = text_or_none(rating_el)

        # 评分人数
        votes_el = soup.select_one('span[property="v:votes"]')
        details["votes"] = text_or_none(votes_el)

        # 5条短评
        reviews = parse_movie_reviews(client, movie_url, max_reviews=5)
        details["reviews"] = " | ".join(reviews)
        
        return details
    except Exception:
        return {
            "douban_id": "", "title": "", "alias": "", "director": "", 
            "summary": "", "rating": "", "votes": "", "reviews": ""
        }

# ---------------- 网格解析与抓取 ----------------

def parse_collect_grid(soup: BeautifulSoup) -> list[dict]:
    rows = []
    for it in soup.select(".grid-view .item, .collect-list .item, .interest-list .item"):
        title_el = it.select_one(".title a, .info h2 a, .title a.nbg")
        title = text_or_none(title_el)
        link = title_el.get("href") if title_el else None
        info = text_or_none(it.select_one(".intro, .pub, .info"))
        date = text_or_none(it.select_one(".date, .time, .collect-date"))
        poster_el = it.select_one("img")
        poster = poster_el.get("src") if poster_el else None
        rows.append({
            "title": title, "info": info, "mark_time": date, 
            "link": link, "poster": poster
        })
    return rows

def crawl_profile(client: DoubanClient, profile_url: str) -> dict:
    soup = client.soup(profile_url)
    out = {}
    m = re.search(r"/people/([^/]+)/", profile_url)
    out["uid"] = m.group(1) if m else None
    h1 = soup.select_one("#db-usr-profile h1, h1")
    out["nickname"] = text_or_none(h1)
    return out

def crawl_collect_movies(client: DoubanClient, uid: str, interest: str, pages: int, enhance: bool) -> list[dict]:
    """interest in {'wish','collect'}；'collect' 即看过"""
    assert interest in {"wish", "collect"}
    all_rows = []
    base_url = f"https://movie.douban.com/people/{uid}/{interest}"

    for p in range(pages):
        params = {"start": p * 15, "sort": "time"}
        try:
            soup = client.soup(base_url, params=params)
            rows = parse_collect_grid(soup)

            if enhance:
                # 批量处理电影详情，不显示单个进度
                for i, row in enumerate(rows):
                    if row.get("link"):
                        details = parse_movie_details(client, row["link"])
                        # 用详情中的标题覆盖原始标题（更准确）
                        if details.get("title"):
                            row["title"] = details["title"]
                        row.update(details)
                        # 减少延迟，但保持礼貌
                        if i % 3 == 0:  # 每3个电影休息一下
                            time.sleep(random.uniform(1, 2))

            all_rows.extend(rows)
            print(f"[OK] 电影/{interest} 第{p+1}/{pages}页 完成，本页{len(rows)}条")
            
        except Exception as e:
            print(f"[WARN] 电影/{interest} 第{p+1}页失败：{e}")
        
        # 页面间延迟
        if p < pages - 1:  # 最后一页不需要延迟
            time.sleep(random.uniform(1, 2))
            
    return all_rows

# ---------------- 主流程 ----------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", required=True, help="你的主页URL，如 https://www.douban.com/people/<uid>/")
    ap.add_argument("--cookies", default=None, help="浏览器复制的cookie整串（建议）")
    ap.add_argument("--pages", type=int, default=2, help="分页数量")
    ap.add_argument("--out_prefix", default="douban_me", help="输出文件前缀")
    ap.add_argument("--enhance-movies", action="store_true", help="抓取导演/简介/短评等详情")
    args = ap.parse_args()

    client = DoubanClient(cookies=args.cookies)
    prof = crawl_profile(client, args.profile)
    uid = prof.get("uid")
    if not uid:
        m = re.search(r"/people/([^/]+)/", args.profile)
        uid = m.group(1) if m else None
    if not uid:
        raise SystemExit("没解析到 uid，请检查 --profile 是否类似 https://www.douban.com/people/<uid>/")

    print(f"开始抓取用户 {uid} 的电影数据...")
    
    # 仅电影想看 & 看过
    movies_wish = crawl_collect_movies(client, uid, interest="wish",    pages=args.pages, enhance=args.enhance_movies)
    movies_done = crawl_collect_movies(client, uid, interest="collect", pages=args.pages, enhance=args.enhance_movies)

    bundle = {
        "profile": {"uid": uid, "nickname": prof.get("nickname")},
        "movies": {"wish": movies_wish, "done": movies_done},
        "meta": {"pages": args.pages, "enhance_movies": args.enhance_movies},
    }

    json_path = f"{args.out_prefix}.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(bundle, f, ensure_ascii=False, indent=2)
    print(f"[OK] 写入 {json_path}")

    # CSV 输出
    def to_csv(rows, name):
        if rows:
            df = pd.DataFrame(rows)
            df.to_csv(f"{args.out_prefix}_{name}.csv", index=False, encoding="utf-8-sig")
            print(f"[OK] 写入 {args.out_prefix}_{name}.csv")

    to_csv(movies_wish, "movies_wish")
    to_csv(movies_done, "movies_done")
    
    print("所有任务完成！")

if __name__ == "__main__":
    main()